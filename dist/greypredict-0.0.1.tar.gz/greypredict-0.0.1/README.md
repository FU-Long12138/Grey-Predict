# Grey-Predict
Short - term Prediction of Poor Data Using Grey Prediction Model
Three grey prediction models are provided. They are GM ( 1,1 ) model, new information GM ( 1,1 ) model and metabolism GM ( 1,1 ) model.
It provides pre-test, grade ratio test and quasi-index test for the data to be predicted.
A post-test function is provided to test the accuracy of the grey model, and the evaluation indexes that can be selected are relative error, mean square error ratio and small error probability.